<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            Copyright {{date('Y')}} <i class="fas fa-copyright"></i> <a class="text-dark" href="https://timerni.com/">Time research & innovation</a>
            {{-- <span>Copyright &copy; {{ config('app.name', 'Laravel') }} @ </span> --}}
        </div>
    </div>
</footer>
