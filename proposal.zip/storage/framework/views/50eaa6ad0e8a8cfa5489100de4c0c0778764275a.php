<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <img src="<?php echo e(asset(getSetting('app-logo')->value)); ?>" alt="Logo" height="30">
        </div>
        <?php if(getSetting('app-name')->value != ""): ?>
        <div class="sidebar-brand-text mx-3"><?php echo e(getSetting('app-name')->value); ?></div>
        <?php endif; ?>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading"> Management </div>

    <!-- Nav Item  -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client-list')): ?>
        <li class="nav-item <?php echo e(request()->routeIs('users.clients') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('users.clients')); ?>">
                <i class="fas fa-solid fa-file"></i>
                <span>Clients</span>
            </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proposal-list')): ?>
        <li class="nav-item <?php echo e(request()->routeIs('users.proposals') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('users.proposals')); ?>">
                <i class="fas fa-solid fa-file"></i>
                <span>Proposals</span>
                <?php if(getProposalCount() > 0): ?>
                <span class="position-absolute top-50 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo e(getProposalCount()); ?>

                </span>
                <?php endif; ?>
            </a>
        </li>
    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
        <!-- Heading -->
        <div class="sidebar-heading"> Admin Section </div>
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#taTpDropDown"
                aria-expanded="true" aria-controls="taTpDropDown">
                <i class="fas fa-user-alt"></i>
                <span>User Management</span>
            </a>
            <div id="taTpDropDown" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">User Management:</h6>
                    <a class="collapse-item" href="<?php echo e(route('users.index')); ?>">List</a>
                    <a class="collapse-item" href="<?php echo e(route('users.create')); ?>">Add New</a>
                    <a class="collapse-item" href="<?php echo e(route('users.import')); ?>">Import Data</a>
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                aria-expanded="true" aria-controls="collapsePages">
                <i class="fas fa-fw fa-folder"></i>
                <span>Masters</span>
            </a>
            <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Role & Permissions</h6>
                    <a class="collapse-item" href="<?php echo e(route('roles.index')); ?>">Roles</a>
                    <a class="collapse-item" href="<?php echo e(route('permissions.index')); ?>">Permissions</a>
                </div>
            </div>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">
    <?php endif; ?>

    <li class="nav-item">
        <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>


</ul>
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/common/sidebar.blade.php ENDPATH**/ ?>