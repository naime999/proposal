<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            Copyright <?php echo e(date('Y')); ?> <i class="fas fa-copyright"></i> <a class="text-dark" href="https://timerni.com/">Time research & innovation</a>
            
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/common/footer.blade.php ENDPATH**/ ?>