<!-- Data Table -->
<link href="<?php echo e(asset('admin/vendor/dataTables/dataTables.bootstrap4.css')); ?>" rel="stylesheet" />
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/common/datatable_style.blade.php ENDPATH**/ ?>