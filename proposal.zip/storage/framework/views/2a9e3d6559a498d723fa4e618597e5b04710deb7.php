<h1>Hello, this is a test email!</h1>
<p>This is the body of your email.</p>
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/emails/example.blade.php ENDPATH**/ ?>