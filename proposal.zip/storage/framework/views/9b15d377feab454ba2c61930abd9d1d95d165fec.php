<nav class="container-fluid bg-white topbar mb-4 static-top shadow d-flex align-items-center justify-content-between">

    <!-- Sidebar Toggle (Topbar) -->
    <div class="d-flex align-items-center justify-content-between">
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu"aria-expanded="false" aria-controls="sidebarMenu"><i class="fas fa-list fa-sm"></i></button>
        <div class="border rounded client-info ml-2 p-2 fs-6 fw-normal">
        </div>
    </div>

    <!-- buttons -->
    <div class="d-flex align-items-right justify-content-between">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proposal-create', 'proposal-edit')): ?>
        <button class="btn btn-sm btn-success" type="submit" onclick="saveData(this)" data-id="<?php echo e($proposal->id); ?>"><i class="fas fa-save pr-2"></i>Save</button>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proposal-create', 'proposal-edit')): ?>
        <button class="btn btn-sm btn-success ml-2" type="submit" onclick="sendData(this)" data-id="<?php echo e($proposal->id); ?>"><i class="fas fa-send pr-2"></i>Send</button>
        <?php endif; ?>
        <a class="btn btn-sm btn-success ml-2" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left pr-2"></i>back</a>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/common/builder.blade.php ENDPATH**/ ?>