<!-- Data Table -->
<script src="<?php echo e(asset('admin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\techtool-laravel-admin\resources\views/common/datatable_js.blade.php ENDPATH**/ ?>